function sendMessage() 
{
    alert("تم إرسال رسالتك بنجاح!");
}